/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.rmi.RemoteException;
import javax.ejb.EJBObject;

/**
 *
 * @author assurgent
 */
public interface StudentRemote extends EJBObject {

    public String getRollNo() throws RemoteException;

    public void setRollNo(String rollNo) throws RemoteException;

    public String getName() throws RemoteException;

    public void setName(String name) throws RemoteException;

    public int getMarks() throws RemoteException;

    public void setMarks(int marks) throws RemoteException;
}
