/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.rmi.RemoteException;
import java.util.Collection;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;
import javax.ejb.FinderException;

/**
 *
 * @author assurgent
 */
public interface StudentRemoteHome extends EJBHome {

    public StudentRemote findByPrimaryKey(String rollNo) throws FinderException, RemoteException;

    public StudentRemote create(String rollNo, String name, int marks) throws CreateException, RemoteException;

    public Collection findByName(String s_name) throws FinderException, RemoteException;

    public Collection findByMarks(int st_marks) throws FinderException, RemoteException;
}
