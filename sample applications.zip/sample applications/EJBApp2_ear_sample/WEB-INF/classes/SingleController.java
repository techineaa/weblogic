/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.naming.Context;
import javax.naming.InitialContext;

import java.util.*;
import javax.rmi.PortableRemoteObject;
import javax.transaction.*;

/**
 *
 * @author assurgent
 */
public class SingleController extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        if (request.getServletPath().equalsIgnoreCase("/addStudent")) {
            addStudent(request, response);
        }
        if (request.getServletPath().equalsIgnoreCase("/searchStudent")) {
            searchStudent(request, response);
        }
        if (request.getServletPath().equalsIgnoreCase("/searchStudentByMarks")) {
            searchStudentByMarks(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>

    private void addStudent(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String rollNo = request.getParameter("rollNo");
        String name = request.getParameter("name");
        String Marks = request.getParameter("marks");
        int marks = Integer.parseInt(Marks);
        String pk = "";
        try {
            Context ctx = getInitialContext();
            Object o = ctx.lookup("st_lookup");
            StudentRemoteHome ejbHome = (StudentRemoteHome) PortableRemoteObject.narrow(o, StudentRemoteHome.class);
            UserTransaction tx = (UserTransaction) ctx.lookup("javax.transaction.UserTransaction");
            tx.begin();
            StudentRemote cBean = ejbHome.create(rollNo, name, marks);
            pk = (String) cBean.getPrimaryKey();
            System.out.println("A student created of rollNo::" + pk);
            tx.commit();
        } catch (Exception ex) {
            System.out.println("Error in addStudent.///" + ex.getMessage());
        }
        if (!pk.equalsIgnoreCase("")) {
            response.sendRedirect("index.jsp?check=Student Added.");
        } else {
            response.sendRedirect("index.jsp?check=Error in Insertion.");
        }
    }

    private void searchStudent(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        StudentRemote student=null;
        String scat = request.getParameter("s_cat");
        try {
            Context ctx = getInitialContext();
            Object o = ctx.lookup("st_lookup");
            StudentRemoteHome ejbHome = (StudentRemoteHome) PortableRemoteObject.narrow(o, StudentRemoteHome.class);
            Collection col=ejbHome.findByName(scat);
            Enumeration en=Collections.enumeration(col);
            while(en.hasMoreElements()){
                student=(StudentRemote)en.nextElement();
                System.out.println("Roll No::"+student.getRollNo()+" Name::"+student.getName()+" Marks::"+student.getMarks());
            }
        } catch (Exception ex) {
            System.out.println("Error in addStudent.///" + ex.getMessage());
        }
    }
    
    private void searchStudentByMarks(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        StudentRemote student=null;
        String smarks = request.getParameter("s_marks");
        int s_marks=Integer.parseInt(smarks);
        try {
            Context ctx = getInitialContext();
            Object o = ctx.lookup("st_lookup");
            StudentRemoteHome ejbHome = (StudentRemoteHome) PortableRemoteObject.narrow(o, StudentRemoteHome.class);
            Collection col=ejbHome.findByMarks(s_marks);
            Enumeration en=Collections.enumeration(col);
            while(en.hasMoreElements()){
                student=(StudentRemote)en.nextElement();
                System.out.println("Roll No::"+student.getRollNo()+" Name::"+student.getName()+" Marks::"+student.getMarks());
            }
        } catch (Exception ex) {
            System.out.println("Error in addStudent.///" + ex.getMessage());
        }
    }

    public static Context getInitialContext() throws javax.naming.NamingException {
        String url = "t3://localhost:7001";
        Properties p = new Properties();
        p.put(Context.INITIAL_CONTEXT_FACTORY,
                "weblogic.jndi.T3InitialContextFactory");
        p.put(Context.PROVIDER_URL, url);
        Context ctx = new InitialContext(p);
        return ctx;

    }
}
