/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.ejb.CreateException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;

/**
 *
 * @author assurgent
 */
public abstract class StudentBean implements EntityBean {

    private EntityContext context;

    public abstract void setRollNo(String rollNo);

    public abstract String getRollNo();

    public abstract void setName(String name);

    public abstract String getName();

    public abstract void setMarks(int marks);

    public abstract int getMarks();


    // <editor-fold defaultstate="collapsed" desc="EJB infrastructure methods. Click on the + sign on the left to edit the code.">

    // TODO Consider creating Transfer Object to encapsulate data
    // TODO Review finder methods
    /**
     * @see javax.ejb.EntityBean#setEntityContext(javax.ejb.EntityContext)
     */
    public void setEntityContext(EntityContext aContext) {
        context = aContext;
    }

    /**
     * @see javax.ejb.EntityBean#ejbActivate()
     */
    public void ejbActivate() {
    }

    /**
     * @see javax.ejb.EntityBean#ejbPassivate()
     */
    public void ejbPassivate() {
    }

    /**
     * @see javax.ejb.EntityBean#ejbRemove()
     */
    public void ejbRemove() {
    }

    /**
     * @see javax.ejb.EntityBean#unsetEntityContext()
     */
    public void unsetEntityContext() {
        context = null;
    }

    /**
     * @see javax.ejb.EntityBean#ejbLoad()
     */
    public void ejbLoad() {
    }

    /**
     * @see javax.ejb.EntityBean#ejbStore()
     */
    public void ejbStore() {
    }

    // </editor-fold>
    public java.lang.String ejbCreate(String rollNo, String name, int marks) throws CreateException {
        if (rollNo == null) {
            throw new CreateException("The field \"key\" must not be null");
        }

        // TODO add additional validation code, throw CreateException if data is not valid
        System.out.println("ejbCreate() is Called.......................////");
        setRollNo(rollNo);
        setName(name);
        setMarks(marks);


        return null;
    }

    public void ejbPostCreate(String rollNo, String name, int marks) {
        // TODO populate relationships here if appropriate
    }
}
