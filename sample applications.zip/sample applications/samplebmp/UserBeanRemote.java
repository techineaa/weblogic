

import java.rmi.RemoteException;

import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.RemoveException;



public interface UserBeanRemote extends javax.ejb.EJBObject{
	
	public   String getUserID()  throws RemoteException;
	public void setUserID(String userID) throws RemoteException; 
	public String getPassword() throws RemoteException;
	public void setPassword(String password) throws RemoteException;	
}
