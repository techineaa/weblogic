

import java.io.Serializable;
import java.rmi.RemoteException;
import javax.naming.*;
import javax.ejb.*;

import java.sql.*;
import javax.sql.DataSource;
public class UserBean implements EntityBean, Serializable {

	   final static boolean VERBOSE = true;	
	   
	      private EntityContext ctx;
	      public            String        userID;	 // also the primary Key
	      public            String        password;

	      private transient boolean       isDirty;   

	public void ejbActivate() throws EJBException, RemoteException {
		// TODO Auto-generated method stub
		log("MESSAGE: *** Login ejbActivate(" +id()+")");

	}
	/*public String ejbFindByPrimaryKey(String userID) throws RemoteException, javax.ejb.FinderException{
			this.userID=userID;
			this.password=password;
			//if present
			return null;
			//else must return null or throw ;
	}*/

	public void ejbLoad() throws EJBException, RemoteException {
		// TODO Auto-generated method stub
		log("MESSAGE: *** Login ejbLoad(" +id()+")");
	}

	public void ejbPassivate() throws EJBException, RemoteException {
		// TODO Auto-generated method stub
		
		log("MESSAGE: *** Login ejbPassivate(" +id()+")");
		

	}

	public void ejbRemove() throws RemoveException, EJBException,
			RemoteException {
		// TODO Auto-generated method stub
		log("MESSAGE: *** Login ejbRemove(" +id()+")");
		//return null;
	}

	public void ejbStore() throws EJBException, RemoteException {
		// TODO Auto-generated method stub
		log("MESSAGE: *** Login ejbStore(" +id()+")");
	}

	public void setEntityContext(EntityContext ctx) throws EJBException,
			RemoteException {
		// TODO Auto-generated method stub
		log("MESSAGE: *** setEntityContext()");
        this.ctx =ctx;

	}

	public void unsetEntityContext() throws EJBException, RemoteException {
		// TODO Auto-generated method stub
		log("MESSAGE: *** unSetEntityContext()");
        this.ctx = null;


	}
    public boolean isModified() 
    {
         log("isModified(): isDirty = " + (isDirty ? "true" : "false"));
         return isDirty;
    }

    public void setModified(boolean flag) 
    {
             isDirty = flag;
    }

    private String id() 
    {
                 return "" + System.identityHashCode(this) + ", PK = " +
                 (String) ((ctx == null) ? "nullctx" : ((ctx.getPrimaryKey() == null ?
                                                          "null" : ctx.getPrimaryKey().toString()))) +"; isDirty = " + isDirty;
    }

	
	
	  public String ejbCreate(String pUserID, String pPassword)	    throws javax.ejb.CreateException, Exception
	  {
		  this.userID = userID;
	        this.password   = "admin";
	        log("EJB CREATE LOGIN BEAN: " + userID);
	        log("LOGIN PASSWORD: " + password);
	        
	           
	    Connection con = null;
	    PreparedStatement ps = null;

	    try 
	    {
	 
	         con = getConnection();
	         String sql = "insert into Login  values (?,?)";
	         ps = con.prepareStatement(sql);


	         ps.setString(1, pUserID);
	         ps.setString(2, pPassword);
	         log  ("Create"+ pUserID + " " + pPassword+ " " );

	          if (ps.executeUpdate() != 1)
	          {
	               String error = "No Rows Inserted";
	               log(error);
	               throw new javax.ejb.CreateException (error);
	          }

	          return pUserID;
	      }  catch (SQLException sqe)
	      {

	            try
	            {
	                   ejbFindByPrimaryKey(pUserID);
	            } catch(Exception onfe)
	            {
	                  String error = "SQLException: " + sqe;
	                  log(error);
	                  throw new javax.ejb.CreateException (error);
	           }

	           String error = "An Account already exists in the database with Primary Key " + pUserID;
	           log(error);
	           throw new Exception(error);
	      } finally
	      {
	           cleanup(con, ps);
	       }
	  }


	
	public void ejbPostCreate(String userID, String passsword){
		/**
		 * Test if such a userName, password exist 
		 */
			log("LOGIN BEAN: POSTCREATE() ID:"+id()+".." );
		
	}



	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	private void log(String s){
		
		if (VERBOSE) System.out.println(s);
	}
	
	  private Connection getConnection()
	    throws SQLException
	  {
	      InitialContext initCtx = null;
	      try 
	      {
	          initCtx = new InitialContext();
	          DataSource ds = (javax.sql.DataSource)
	          initCtx.lookup("java:comp/env/jdbc/lal");
	          return ds.getConnection();
	       } catch(NamingException ne)
	       {
	          log("Failed to lookup JDBC Datasource. Please double check that");
	          log("the JNDI name defined in the resource-description of the ");
	          log("EJB's weblogic-ejb-jar.xml file is the same as the JNDI name ");
	          log("for the Datasource defined in your config.xml.");
	          throw new EJBException(ne);
	      }
	      finally 
	      {
	           try 
	           {
	                 if(initCtx != null) 
	                        initCtx.close();
	           } catch(NamingException ne) 
	           {
	                      log("Error closing context: " + ne);
	                       throw new EJBException(ne);
	           }
	     }
	  }

	  
	  public String ejbFindByPrimaryKey(String pUserName)
		    throws Exception
	  {
	   
	    log(" ejbFindByPrimaryKey ");

	    Connection con = null;
	    PreparedStatement ps = null;
	    String sUserID =null,sPassword = null;
	    try
	    {
	           con = getConnection();
	           ps  = con.prepareStatement("select * from Login where userId = ?");
	           ps.setString(1, pUserName);
	           ps.executeQuery();
	           ResultSet rs = ps.getResultSet();
	           if (rs.next())
	            {
	                   sUserID = rs.getString(1);
	                   sPassword = rs.getString(2);
	                   
	            }
	            else 
	            {
	                   String error = "ejbFindByPrimaryKey: userBean (" + pUserName + ") not found";
	                   log(error);
	                   throw new Exception (error);
	            }
	     } catch (SQLException sqe) 
	    {
	           log("SQLException:  " + sqe);
	           throw new EJBException (sqe);
	    } finally 
	    {
	      cleanup(con, ps);
	    }

	    return sUserID;
	  }

	  private void cleanup(Connection con, PreparedStatement ps) 
	  {
	      try 
	      {
	            if (ps != null) 
	                  ps.close();
	      } catch (Exception e) {
	            log("Error closing PreparedStatement: "+e);
	            throw new EJBException (e);
	      }
	  
	      try 
	      {
	             if (con != null) 
	                 con.close();
	      } catch (Exception e) 
	      {
	           log("Error closing Connection: " + e);
	           throw new EJBException (e);
	      }
	   }

}
