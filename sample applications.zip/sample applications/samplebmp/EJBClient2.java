


import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import javax.transaction.*;

public class EJBClient2  {
	public static void main(String args[]) throws NamingException, Exception{
		
			    
	  
		
		
		createUser("nagaraj","vizag");
		
	}
	
	public static Context getInitialContext() throws javax.naming.NamingException{
		String url = "t3://localhost:7001"; 
		Properties p = new Properties();
	    p.put(Context.INITIAL_CONTEXT_FACTORY,
	     "weblogic.jndi.T3InitialContextFactory");
	    p.put(Context.PROVIDER_URL, url);
	    Context ctx = new InitialContext(p);
	    return ctx;
		
	}
	
	public static void createUser(String userName, String password) throws NamingException, Exception{
		
		 Context ctx = getInitialContext(); 
		 Object o = ctx.lookup("beanManagedUser1"); 
		 UserHome ejbHome = (UserHome) PortableRemoteObject.narrow(o,UserHome.class);
		UserTransaction tx=(UserTransaction)ctx.lookup("javax.transaction.UserTransaction");
		tx.begin();
		 UserBeanRemote cBean= ejbHome.create(userName, password);
		 System.out.println("commiting creating user.. ");
		 
		 tx.commit();
		 System.out.println("committed back successfully");
	}
	
	
	
}
