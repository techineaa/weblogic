

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;

public interface UserHome extends  javax.ejb.EJBHome{
	
	public UserBeanRemote create(String userID,String password) throws Exception; 
	public UserBeanRemote findByPrimaryKey(String userID) throws Exception;
	 
	
	//public LoginBeanRemote remove(String userID) throws RemoteException, RemoveException; 

}
