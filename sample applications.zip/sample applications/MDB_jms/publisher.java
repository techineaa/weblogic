	import javax.ejb.*;
	import javax.jms.*;
	import javax.naming.*;
	import java.rmi.*;
	import java.util.*;
	import java.awt.*;

	public class publisher  extends Frame
	{
		TextField text1;
		Button button1, button2;
		TopicPublisher  topicpub;
		TextMessage tm;
	
		public static void main (String args[])
		{
			publisher app = new  publisher();
			app.resize(400,500);
			app.show();
              }
			publisher()
			{
				try
				{
				setLayout(new FlowLayout());
				setBackground (Color.red);
				text1=new TextField (40);
				button1 = new Button("Send");
				button2 = new Button ("Exit");
				add(text1);
				add(button1);
				add(button2);
				System.out.println ("Please wait.....................");
				Properties props = new Properties();
				props.put (Context.INITIAL_CONTEXT_FACTORY,"weblogic.jndi.WLInitialContextFactory");
				props.put (Context.PROVIDER_URL,"t3://localhost:7001");
				Context context = new InitialContext(props);
				System.out.println ("Ok....................");
				TopicConnectionFactory factory = (TopicConnectionFactory) context.lookup ("India");
				TopicConnection connection  = factory.createTopicConnection();
				System.out.println ("Factory Ok................");
				TopicSession session = connection.createTopicSession(false,Session.AUTO_ACKNOWLEDGE);
				Topic topic = (Topic) context.lookup ("mrinal");
				System.out.println ("Topic Ok...............");
				topicpub = session.createPublisher(topic);
				tm = session.createTextMessage();
				
			
				}
				catch(Exception e1) {System.out.println (e1);}				


			}

				public boolean action (Event e, Object c)
				{
				if (e.target==button1)
				{
				try
				{
				String s = text1.getText();
				tm.setText(s);
				topicpub.publish(tm);
				System.out.println ("Message published");
				
				}
				catch (Exception e1) { System.out.println ("" +  e1);}			
				}

				if (e.target==button2)	
				{
				System.exit(0);
				}
				return true;
				}


               
}
