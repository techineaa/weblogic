import java.rmi.*;
import javax.jms.*;
import javax.ejb.*;
import javax.naming.*;
import java.util.*;
import java.io.*;

public class mdb implements MessageDrivenBean,  MessageListener
	{
		public void ejbCreate(){}

		public void ejbRemove(){}

		public void setMessageDrivenContext (MessageDrivenContext mdc) {}
		
		public void onMessage(Message msg)	
		{
			try
			{
			System.out.println ("Receiving  The Message From Publisher");
			TextMessage tm = (TextMessage) msg;
			String s = tm.getText();
			System.out.println  (s);
			}catch (Exception e) {System.out.println (e); }
		}

	}