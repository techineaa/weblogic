export JAVA_HOME=/usr/java/jdk1.7.0_80/;
export JRE_HOME=/usr/java/jdk1.7.0_80/jre/;
export CLASSPATH=$CLASSPATH:/home/root1/Oracle/Middleware/Oracle_Home/wlserver/server/lib/weblogic.jar ;
export CLASSPATH=$CLASSPATH:/usr/java/jdk1.7.0_80/lib/tools.jar
export PATH=/usr/java/jdk1.7.0_80/bin:/usr/java/jdk1.7.0_80/jre/bin:$PATH
export CLASSPATH=$CLASSPATH:/usr/java/jdk1.7.0_80/jre/lib/;
